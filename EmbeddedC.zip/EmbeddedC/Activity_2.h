#ifndef __ACTIVITY_2_H_
#define __ACTIVITY_2_H_

#include <avr/io.h>
#include<util/delay.h>
#include <avr/interrupt.h>

void InitADC();
uint16_t ReadADC(uint8_t ch);

#endif /** __Activity_2_H_ */
