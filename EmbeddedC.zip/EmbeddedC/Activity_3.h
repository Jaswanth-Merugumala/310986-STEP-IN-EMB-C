#ifndef __ACTIVITY_3_H_
#define __ACTIVITY_3_H_
#include <avr/io.h>
#include <util/delay.h>


void timer();

char PWM(uint16_t temp);


#endif /** __ACTIVITY_3_H_ */
