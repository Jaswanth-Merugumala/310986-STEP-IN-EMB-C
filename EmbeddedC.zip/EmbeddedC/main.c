#include "Activity_1.h"
#include "Activity_2.h"
#include "Activity_3.h"

char temp_data;
int main(void)
{
	/* Initialize Peripherals */
    InitADC();
    char temp_data;
    uint16_t temp;
	peripheral_init();
    timer();

	while (1)
	{
        change_led_state(PD0);
		delay_ms(1000);
        temp=ReadADC(0);
        _delay_ms(200);
        temp_data = PWM(temp);
        OCR0A=0;
        _delay_ms(200);
	}
	return 0;
}
